// let para = document.getElementsByClassName("para");
// let flex = document.getElementsByClassName("flex")
function toggle(){
let para = document.getElementsByClassName("para");
    if (para.style.display == "none"){
        para.style.display = "block";
    }else{
        para.style.display = "none";
    }
} 